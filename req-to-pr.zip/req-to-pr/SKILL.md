---
name: req-to-pr
description: 'End-to-end workflow for implementing a requirement and landing it as a PR with passing CI. This skill should be used when the user provides a bug report, feature request, or code change requirement and expects a complete implementation delivered as a GitHub pull request. Trigger phrases include "fix this and create a PR", "implement this end to end", "land this as a PR", "make a PR for this", or any requirement followed by an expectation that it will be committed, pushed, and merged.'
---

# Requirement to PR

Implement a user-provided requirement end-to-end: from understanding the problem, through code changes, to a merged-ready PR with green CI. The user may interrupt with feedback at any point; incorporate it and continue toward completion.

## Workflow

### Phase 1: Understand

1. Read the requirement carefully. Identify the affected area of the codebase.
2. Use the Explore agent or Grep/Glob to find all relevant code paths. Read the files before making changes.
3. If the requirement is ambiguous, ask one focused clarifying question rather than guessing.

### Phase 2: Implement

1. Make the minimal, focused code change that addresses the requirement. Follow existing code conventions (read CLAUDE.md if present).
2. Prefer editing existing files over creating new ones.
3. Avoid over-engineering: no extra features, no unnecessary refactors, no unrelated cleanups.

### Phase 3: Validate locally

1. Run the project's lint/typecheck/test commands (check CLAUDE.md, Makefile, package.json, or pyproject.toml for the right commands).
2. Fix any failures before proceeding. Do not skip or disable checks.
3. If tests take a long time, run them in the background and proceed to branch creation while waiting.

### Phase 4: Branch, commit, push, and PR

1. Create a descriptive branch name (e.g. `fix/graceful-status-no-table`).
2. Stage only the relevant files (avoid `git add -A`).
3. Write a clear commit message: short summary line, optional body explaining "why".
4. Push with `-u` to set upstream tracking.
5. Create the PR with `gh pr create`:
   - Title: short, under 70 characters.
   - Body: `## Summary` with bullet points, `## Test plan` with checklist.
6. Report the PR URL to the user.

### Phase 5: Monitor CI

1. Run `gh pr checks NUMBER --watch` in the background to monitor CI.
2. When CI completes:
   - If all checks pass, report success to the user.
   - If any check fails, investigate the failure logs with `gh run view RUN_ID --log-failed`, fix the issue, commit, push, and monitor again.
3. Repeat until all checks are green.

## Handling user interruptions

The user may interrupt at any phase with feedback such as "don't do it that way", "also handle X", or "use a different approach". When this happens:

1. Stop the current action immediately.
2. Acknowledge the feedback concisely.
3. Incorporate the feedback into the implementation.
4. Resume the workflow from the appropriate phase. Do not restart from scratch unless the feedback fundamentally changes the approach.

If the user rejects a tool call, do not retry the same call. Adjust the approach based on the implicit or explicit reason for rejection.

## Key principles

- **Minimal diffs**: Change only what the requirement asks for. Reviewers appreciate small, focused PRs.
- **Read before writing**: Always read the code before modifying it. Understand the existing patterns.
- **No silent failures**: If a test or lint check fails, fix the root cause. Never use `--no-verify` or skip hooks unless the user explicitly says so.
- **Stay on track**: The goal is a green PR. Every action should move toward that goal.
- **Communicate at milestones**: Brief status updates at phase transitions. No play-by-play narration.
